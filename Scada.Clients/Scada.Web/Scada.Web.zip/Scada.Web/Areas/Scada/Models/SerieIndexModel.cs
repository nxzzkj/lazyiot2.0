﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ScadaWeb.Web.Areas.Scada.Models
{
   
    public class SerieIndexModel
    {
        public string id
        {
            set;
            get;
        }

        public string name
        {
            set;
            get;
        }
        public string value
        {
            set;
            get;
        }
    }
}